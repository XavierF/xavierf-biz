# [BootstrapWP - Wordpress Theme Framework v0.1 ](http://upplex.de/bootstrap-3-wordpress-theme-framework/)

This is the first release and in early stage. Based on Twitter Bootstrap 3.0.0

To get started with Bootstrap 3, check out [http://getbootstrap.com](http://getbootstrap.com)!

By [upplex - webdesign](http://upplex.de)

## Quick start

Copy the Folder in your Wordpress theme folder and enable it. 

## Bugs and feature requests

Have a bug or a feature request? [Please open a new issue](https://github.com/upplex/upBootstrap3WP/issues).

## Contributing

Submit your pull request and I will check it.

## Copyright and license

Copyright 2013 upplex under GPL 3.0(LICENSE)
